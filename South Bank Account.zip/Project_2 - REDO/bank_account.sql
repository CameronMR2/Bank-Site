-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2017 at 05:07 AM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bank_account`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `TypeID` int(6) NOT NULL AUTO_INCREMENT,
  `Type` text NOT NULL,
  `Interest` int(11) NOT NULL,
  PRIMARY KEY (`TypeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`TypeID`, `Type`, `Interest`) VALUES
(1, 'Checking', 5),
(2, 'Savings', 3),
(3, 'Credit Card', 10),
(4, 'Foreign Market Fund', 12),
(5, 'College Saving Account', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bank_account`
--

CREATE TABLE IF NOT EXISTS `bank_account` (
  `AccountID` int(10) NOT NULL AUTO_INCREMENT,
  `TypeID` int(6) NOT NULL,
  `FirstName` char(15) NOT NULL,
  `LastName` char(15) NOT NULL,
  `Balance` double NOT NULL,
  PRIMARY KEY (`AccountID`),
  KEY `TypeID` (`TypeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2007 ;

--
-- Dumping data for table `bank_account`
--

INSERT INTO `bank_account` (`AccountID`, `TypeID`, `FirstName`, `LastName`, `Balance`) VALUES
(11, 1, 'James', 'Cameron', 200),
(12, 2, 'Johny', 'Depp', 1500),
(55, 3, 'Charles', 'Banner', 250),
(1511, 5, 'Han', 'Solo', 1500),
(2002, 4, 'Johnny', 'Bravo', 5),
(2006, 7, 'Captain', 'Procrastinator', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
