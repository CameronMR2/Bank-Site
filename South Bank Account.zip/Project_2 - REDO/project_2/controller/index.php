<?php
	
	//Programmed by: Cameron Mosley
	//Changes that were made from my original submittion - Update information function, deposit/withdrawal, login <although this must be Admin admin>, MVC format. 
	//I wasn't able to inforce referintial intergrity. I tried to research it, but wasn't able to get it functioning. 
	$lifetime = 60 * 60 * 24 * 2;    // 2 days
	session_set_cookie_params($lifetime, '/');
	session_start();
	require ('../model/database.php');
	require ('../model/accounts_db.php');

	 
	//create action variable for the if else statements 
	$action = filter_input(INPUT_POST, 'action');
	if ($action==NULL) {
	 $action = filter_input(INPUT_GET, 'action');
	 if ($action ==NULL) {
	 $action = 'list_accounts';
	 }
	 }
	
	
	//list all the account info
	if ($action == 'list_accounts') {
		$accounts = get_accounts();
	 include('../view/view_accounts.php');
	 //if action is to update the balance, update_amount is called
	} else if ($action == 'update_amount') { 
	$account_number = filter_input(INPUT_POST, 'accountSelect');
	$amount  = filter_input(INPUT_POST, 'balance');
	update_balance($account_number, $amount); 
	
	header("Location:.");
	 
	}else if ($action == 'delete_account') {
 //get the account id from post array
	$account_num = filter_input(INPUT_POST, 'account_number',
	FILTER_VALIDATE_INT);
	delete_account($account_num);
	header("Location:.");
	} else if ($action == 'update_bankAccount') 
	{
		$account_num = filter_input(INPUT_POST, 'accountSelect');
		$amount = filter_input(INPUT_POST, 'balance');
		$firstName = filter_input(INPUT_POST, 'firstName');
		$lastName = filter_input(INPUT_POST, 'lastName');
		update_information($firstName, $lastName, $amount, $account_num);
		header("Location:.");		
	//add a bank account to the array 
 } else if ($action == 'add_bankAccount'){
 $account_num = filter_input(INPUT_POST, 'accountID'); 
 $typeID = filter_input(INPUT_POST, 'typeID'); //Since there is no referential integrity, this doesn't change the account table 
 $lastName = filter_input(INPUT_POST, 'lastName');
 $firstName = filter_input(INPUT_POST, 'firstName');
 $balance = filter_input(INPUT_POST, 'balance');

 
 //create query to indert all the bank information
 $addQuery = 'INSERT INTO bank_account
 (AccountID, TypeID, FirstName, LastName, Balance)
 VALUES
 (:accountNumber, :typeID, :firstName, :lastName,
:balance)';
 //try catch
 try {
 // create statement object
 $addStatement = $db-> prepare($addQuery);
 // bind paramenters
 $addStatement->bindValue(':accountNumber', $account_num);
 $addStatement->bindValue(':typeID', $typeID);
 $addStatement->bindValue(':firstName', $lastName);
 $addStatement->bindValue(':lastName', $firstName);
 $addStatement->bindValue(':balance', $balance);
 // execute query
 $addStatement->execute();
 // close connection
 $addStatement->closeCursor();
 
 header("Location:.");
 
 }catch (Exception $e){
 $error_message = $e->getMessage();
 echo "Error message " . $error_message;


 }}

	
	

?>