 <?php 
	require ('../model/database.php');
	require ('../model/accounts_db.php');
	$accounts = get_accounts();
?>

    <header>
		<img src ="../view/logo.png" alt = "jaguar">
		<link rel="stylesheet" href="../view/main.css">
    </header>
    <main>	

 <div id= "deposit">
  <h1>Deposit</h1>

 <form action="../controller/index.php" method="post" id="add_balance">

 <input type="hidden" name="action" value="update_amount">
<!--User can select a certain account to deposit money in--> 
 <label>Select Account:</label>
  <select name="accountSelect">
                <?php foreach( $accounts as $account ) : ?>
                    <option value="<?php echo $account['AccountID']; ?>">
                        <?php echo 'Acount ID [' . $account['AccountID'] . ']' . ' - ' . $account['FirstName'] . ' ' . $account['LastName'] . ', Balance = $' . number_format($account['Balance'], 2); ?>
                    </option>
                <?php endforeach; ?>
            </select>
			<br>
			<br>
 <!--Deposit amount can be entered into the text box below-->
 <label>Deposit: </label>
 <br>
 <input type="input" name="balance" />
 <br />
			
 <label>&nbsp;</label>
 <br>
 <input type="submit" value="Deposit" />
 <br />
 <br>
 <a href="../view_account.php"><button>Back</button></a>
 
 </form>
 </div>