<!DOCTYPE html>
<html>

<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="stle.css">
	<link href="https://fonts.googleapis.com/css?family=Lato:400,700i" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
</head>
<body>

<div class="container">
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="http://www.southalabama.edu/"><i class="fa fa-graduation-cap" aria-hidden="true"></i> South Alabama Bank</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="./">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Content</a></li>
      </ul>
      
      <ul class="nav navbar-nav navbar-right">
      	<li><a href="../view/logout.php">Logout  <i class="fa fa-user-plus" aria-hidden="true"></i></a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</div>

    <header>
        <h1 id= "title">Jaguar Bank Account</h1>
		<img src ="../view/logo.png" alt = "jaguar">
		<link rel="stylesheet" href="../view/main.css">
    </header>
    <main>	

	
<table>

 <tr>
 <th>|Account ID|</th>
<th>|First Name|</th>
 <th>|Last Name|</th>
 <th>|Balance|</th>
<!--List out accounts from DB and give the ability to delete-->
 </tr>
 <?php foreach ($accounts as $account): ?>
 <tr>
 <td><?php echo $account['AccountID']; ?></td>
 <td><?php echo $account['FirstName']; ?></td>
 <td><?php echo $account['LastName']; ?></td>
 <td><?php echo number_format($account['Balance'], 2); ?></td>
 
 <td><form action="." method="post">
 <input type="hidden" name="action"
value="delete_account">
 <input type="hidden" name="account_number"
value="<?php echo $account['AccountID']; ?>" />
 <input type="submit" value="Delete" />
 </form> </td>
 </tr>
 <?php endforeach; ?>
 </table>
 
 </form>

 <br>
 <br>
 
 

 <a href="../view/account_add.php"><button>Add Account</button></a>
 <a href="../view/withdrawal.php"><button>Withdraw</button></a>
 <a href="../view/deposit.php"><button>Deposit</button></a>
 <a href="../view/update_information.php"><button>Update Account</button></a>
 
 </div>
   
    </main>
</body>
</html>