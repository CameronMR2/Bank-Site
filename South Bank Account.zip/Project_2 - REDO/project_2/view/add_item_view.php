<!DOCTYPE html>
<html>

<body>
    <header>
        <h1 id= "title">Jaguar Bank Account</h1>
		<img src ="../view/logo.png" alt = "jaguar">
		<link rel="stylesheet" href="../view/main.css">
    </header>
    <main>	

	
<table>

 <tr>
 <th>|Account ID|</th>
<th>|First Name|</th>
 <th>|Last Name|</th>
 <th>|Balance|</th>
<!--List out accounts from DB and give the ability to delete-->
 </tr>
 <?php foreach ($accounts as $account): ?>
 <tr>
 <td><?php echo $account['AccountID']; ?></td>
 <td><?php echo $account['FirstName']; ?></td>
 <td><?php echo $account['LastName']; ?></td>
 <td><?php echo number_format($account['Balance'], 2); ?></td>
 
 <td><form action="." method="post">
 <input type="hidden" name="action"
value="delete_account">
 <input type="hidden" name="account_number"
value="<?php echo $account['AccountID']; ?>" />
 <input type="submit" value="Delete" />
 </form> </td>
 </tr>
 <?php endforeach; ?>
 </table>
 
 </form>

 <br>
 <br>


 <a href="../view/logout.php"><button>Log Out</button></a>
 <a href="../view/account_add.php"><button>Add Account</button></a>
 </div>
   
    </main>
</body>
</html>