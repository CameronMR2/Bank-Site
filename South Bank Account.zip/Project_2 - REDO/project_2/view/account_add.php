<header>
		<img src ="../veiw/logo.png" alt = "jaguar">
		<link rel="stylesheet" href="../veiw/main.css">
    </header>

<section id= "add_account">
 <h1>Add Account</h1>

 <form action="../controller/index.php" method="post" id="add_employee_form">

 <input type="hidden" name="action" value="add_bankAccount">

 
 <label id= "add_account_text">Account Type: </label>
 <br>
 <input id= "add_account_text" type="input" name="accountID" />
 <br>
 <br>

 <label id= "add_account_text">Type ID: </label>
 <br>
 <input id= "add_account_text" type="input" name="typeID" />
 <br>
 <br>

 <label id= "add_account_text">First Name: </label>
 <br>
 <input id= "add_account_text" type="input" name="lastName" />
<br>
 <br>

 <label id= "add_account_text">Last Name: </label>
 <br>
 <input id= "add_account_text" type="input" name="firstName" />
<br>
 <br>

 <label id= "add_account_text">Balance: </label>
 <br>
 <input id= "add_account_text" type="input" name="balance" />
<br>
 <br>

 <label>&nbsp;</label>
 <input id= "add_account_button" type="submit" value="Add Bank Account" />


 </form>
 

 
 </section>
