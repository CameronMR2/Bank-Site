 <?php 
	require ('../model/database.php');
	require ('../model/accounts_db.php');
	$accounts = get_accounts();
?>



    <header>
		<img src ="../view/logo.png" alt = "jaguar">
		<link rel="stylesheet" href="../view/main.css">
    </header>
    <main>	

 <div id= "deposit">
  <h1>Withdraw</h1>

 <form action="../controller/index.php" method="post" id="add_balance">

 <input type="hidden" name="action" value="update_amount">

 <!-- User will select the amount to withdraw from drop down box going to $200-->
 <!-- if statement will be used in the index page to determine if the amount is applicable-->
 <label>Select Account:</label>
  <select name="accountSelect">
                <?php foreach( $accounts as $account ) : ?>
                    <option value="<?php echo $account['AccountID']; ?>">
                        <?php echo 'Acount ID [' . $account['AccountID'] . ']' . ' - ' . $account['FirstName'] . ' ' . $account['LastName'] . ', Balance = ' . '$' .number_format($account['Balance'], 2); ?>
                    </option>
                <?php endforeach; ?>
            </select>
			<br>
			<br>
		<!--I tried to get the amount to represent the current acount selected. Ultimately chose to set the max withdrawal to 200-->
		<label>Withdrawal Amount:</label>
		<select name="balance">
                <?php for($amount = 20; $amount <= 200; $amount += 20) : ?>
                    <option value="<?php echo (-$amount); ?>">
                        <?php echo $amount; ?>
                    </option>
                <?php endfor; ?>
            </select>
			<br>
			<br>
 
 <input type="submit" value="Withdraw" />
 <br />
 <br>
 <a href="../view_account.php"><button>Back</button></a>
 
 </form>
 </div>