 <?php 
	require ('../model/database.php');
	require ('../model/accounts_db.php');
	$accounts = get_accounts();
?>

<header>
		<img src ="../view/logo.png" alt = "jaguar">
		<link rel="stylesheet" href="../view/main.css">
    </header>

<section id= "add_account">
 <h1>Update Account</h1>

 <form action="../controller/index.php" method="post" id="update_info">

 <input type="hidden" name="action" value="update_bankAccount">
 
  <label>Select Account:</label>
  <select name="accountSelect">
                <?php foreach( $accounts as $account ) : ?>
                    <option value="<?php echo $account['AccountID']; ?>">
                        <?php echo 'Acount ID [' . $account['AccountID'] . ']' . ' - ' . $account['FirstName'] . ' ' . $account['LastName'] . ', Balance = ' . '$' .number_format($account['Balance'], 2); ?>
                    </option>
                <?php endforeach; ?>
            </select>
			<br>
			<br>

 <label id= "add_account_text">First Name: </label>
 <br>
 <input id= "add_account_text" type="input" name="firstName" />
<br>
 <br>

 <label id= "add_account_text">Last Name: </label>
 <br>
 <input id= "add_account_text" type="input" name="lastName" />
<br>
 <br>

 <label id= "add_account_text">Balance: </label>
 <br>
 <input id= "add_account_text" type="input" name="balance" />
<br>
 <br>

 <label>&nbsp;</label>
 <input id= "add_account_button" type="submit" value="Save Changes" />


 </form>
 

 
 </section>
