<?php
function get_accounts() { 
	 //Connect to DB.
	global $db;
	
	//write query to display accounts
	$query = 'SELECT * FROM bank_account';
	// prepare the SQL statement for execute, return PDO statement object
	$statement = $db ->prepare($query);
	//Execute SQL query.
	$statement->execute();	
	// retrieve the data with fetch all
	$accounts = $statement->fetchAll();	
	//Close
	$statement->closeCursor();
	
	return $accounts; 
}

function delete_account($account_number) { 
	global $db;
	 //Create query
	 $query = "DELETE FROM bank_account WHERE AccountID = :user_num";
	 // prepare the SQL statement for execution, returns a PDO statement
	//object
	 $statement = $db -> prepare($query);
	 // add parameters to statement object
	 $statement-> bindValue (':user_num', $account_number);
	 //execute query
	 $statement->execute();
	 // close cursor and free database connetion
	 $statement->closeCursor();	
}

//Both the amount and account number will be sent from the deposit/withdraw 
//page. From there, this either add on the value or subtract(- value added 
//the withdrawal page in withdrawal.php)
function update_balance($account_number, $amount) {
	global $db; 
	$query = "UPDATE bank_account SET Balance = Balance + :amount WHERE AccountID = :person";
	$statement = $db -> prepare($query);
	$statement-> bindValue (':person', $account_number);
	$statement-> bindValue (':amount', $amount);	
	
	$statement->execute();
	
	$statement->closeCursor();	
}

function update_information($firstName, $lastName, $amount, $account_num){ 
	global $db; 
	$query = "UPDATE bank_account SET FirstName = :firstName, LastName = :lastName, Balance = :balance WHERE AccountID = :person";
	$statement = $db -> prepare($query);
	$statement-> bindValue (':person', $account_num);
	$statement-> bindValue (':balance', $amount);
	$statement-> bindValue (':firstName', $firstName);	
	$statement-> bindValue (':lastName', $lastName);		
	
	$statement->execute();
	
	$statement->closeCursor();	
}

?>
	
