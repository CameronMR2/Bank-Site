<!DOCTYPE HTML>

<?php 
//Programmed by: Cameron Mosley 
//Session for the login starts 
	session_start();
	//I set the username and password to these values.
	//I wasn't able to get these values to pass to the database.php page to validate the user.
	$username = "Admin"; 
	$password = "admin"; 
	
	if (isset($_SESSION['Logged_in']) && $_SESSION['Logged_in'] == true) { 
		header("Location: controller/index.php"); 
	}
	//if the Post for user and password are set then it will check idf they match the above //variables.
	if (isset($_POST['username']) && isset($_POST['password'])) {
			if ($_POST['username'] == $username && $_POST['password'] == $password)
				{
					$_SESSION['Logged_in'] = true; 
					header("Location: controller/index.php");
				}
		}
		
?>

<html>
<head> 

	<title>South Bank</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="stle.css">
	<link href="https://fonts.googleapis.com/css?family=Lato:400,700i" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

<style type="text/css">

	
	header {
			background-image: -webkit-linear-gradient(
				50deg, white 10%, red 90%, black 100%);
			background-image: -moz-linear-gradient(
				50deg, white 10%, red 90%, black 100%);
			background-image: -o-linear-gradient(
				50deg, white 10%, red 90%, black 100%);
			background-image: linear-gradient(
				50deg, white 10%, red 90%, black 100%);
			margin: 0.025em;
			border-bottom: 2px solid red;
		}

	 body { 
 		background: url("https://c2.staticflickr.com/8/7450/12070228055_ac668065b3_b.jpg");
 		background-size: cover;
 		background-position: center;
 		font-family: lato;
 		color:white;
 		margin-top: 2px;
  }

  #content input {
  		color:black;
  }

	h1, h2 {
	    margin-top: 0;
	    color: White;
	}

	#logo { 
		float: right;
	 }
	/*formatting for the add pages. IE showed changes while Chrome wouldn't show margin changes.*/
	#add_account {
				margin-left: 0px;
				color: white; 
				border-style: solid;
				border-bottom: solid white;
				background: #00008B;
				
	}

	#login { 
			color: blue; 
			}
				
	#add_account_text {
				margin-left: 5px;
	}

	#add_account_button {
				margin-left: 5px;
				color: black; 			
	}
				

	div { 
			text-align: left; 
			}
	span {
		color: White;
	}


	aside {
			color: white;
	}

	#right {
			float: right; 
			width: 50%;
			margin: .5em;
	}

	#title {
			color : black;
	}

	input {
	    display: block;
	    float: left;
	    margin-bottom: .5em;
	    margin-top: 0;
	}

	img { 
			width: 100px;
			
			}
	

	#logo { 
			width: 15%;
			float: left;
	 }

			footer {
				color:white;
				margin-left: 30px;
				margin-top: 100px;
			}

</style>



</head>
	<body> 
	
	<!--<div class= "jumbotron">
	<div class = "container">
		<div class="col1" style="float:left;width:40%;">
			<h1 id= "login"><img  src ="veiw/logo.png" alt = "jaguar"> Login</h1>
				<form method="post" action="index.php"> 
				username:</br> 
				<input type="text" name="username"></br> </br> 
				Password:</br> 
				<input type="password" name="password"></br></br></br>
				<input type="submit" value="Login">
			</form> 
		</div>
		<div class="col2" style="float:right;width:60%;"><img id = "moulton" src="http://media.al.com/live/photo/south-alabama-moulton-towerjpg-3ed59444628c1452.jpg"> </div>
	</div>
	</div> -->
<div class="container">
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="http://www.southalabama.edu/"><i class="fa fa-graduation-cap" aria-hidden="true"></i> South Alabama Bank</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Content</a></li>
      </ul>
      
      <ul class="nav navbar-nav navbar-right">
      	<li><a href="#">Sign up  <i class="fa fa-user-plus" aria-hidden="true"></i></a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</div>


	<!--<div class="jumbotron jumbotron-billboard">
	  <div class="img"></div>
	    <div class="container">
	        <div class="row">
	            <div class="col-lg-12">
	                <h1 id= "login"><img  src ="veiw/logo.png" alt = "jaguar"> Login</h1>
					<form method="post" action="index.php"> 
					username:</br> 
					<input type="text" name="username"></br> </br> 
					Password:</br> 
					<input type="password" name="password"></br></br></br>
					<input class="btn btn-success btn-lg" type="submit" value="Login">
					</form> 

	            </div>
	        </div>
	    </div>
	</div>-->



	<div class="container"> 
	<div class="row"> 
		<div class="col-lg-12">
			<div id="content">
		
			 <h1 id= "login"><img  src ="veiw/logo.png" alt = "jaguar"></h1>
					<form method="post" action="index.php"> 
					username:</br> 
					<input type="text" name="username" placeholder="Username"></br> </br> 
					Password:</br> 
					<input type="password" name="password" placeholder="password"></br></br></br>
					<input class="btn btn-success btn-lg" type="submit" value="Login">
					</form> 
			 </div>
		</div>
	</div>
</div>



<footer>By: Cameron Mosley</footer>

<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body> 
</html>
