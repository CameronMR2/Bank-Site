<!DOCTYPE html>
<html>

<body>
    <header>
        <h1 id= "title">Jaguar Bank Account</h1>
		<img src ="../veiw/logo.png" alt = "jaguar">
		<link rel="stylesheet" href="../veiw/main.css">
    </header>
    <main>	

	
<table>

 <tr>
 <th>|Account ID|</th>
<th>|First Name|</th>
 <th>|Last Name|</th>
 <th>|Balance|</th>
<!--List out accounts from DB and give the ability to delete-->
 </tr>
 <?php foreach ($userInfo as $user): ?>
 <tr>
 <td><?php echo $user['AccountID']; ?></td>
 <td><?php echo $user['FirstName']; ?></td>
 <td><?php echo $user['LastName']; ?></td>
 <td><?php echo number_format($user['Balance'], 2); ?></td>
 
 <td><form action="." method="post">
 <input type="hidden" name="action"
value="delete_employee">
 <input type="hidden" name="employee_number"
value="<?php echo $user['AccountID']; ?>" />
 <input type="submit" value="Delete" />
 </form> </td>
 </tr>
 <?php endforeach; ?>
 </table>
 
 </form>
 <br>
 <br>
 <!-- I couldn't get the variables to transfer from my add page -->
 <!-- So I decided to put it on the same page. I realize this isn't ideal. -->
 <section id= "add_account">
 <h1>Add Account</h1>

 <form action="index.php" method="post" id="add_employee_form">

 <input type="hidden" name="action" value="add_employee">

 
 <label id= "add_account">Account Type: </label>
 <br>
 <input type="input" name="accountID" />
 <br>
 <br>

 <label id= "add_account">Type ID: </label>
 <br>
 <input type="input" name="typeID" />
 <br>
 <br>

 <label id= "add_account">First Name: </label>
 <br>
 <input type="input" name="lastName" />
<br>
 <br>

 <label id= "add_account">Last Name: </label>
 <br>
 <input type="input" name="firstName" />
<br>
 <br>

 <label id= "add_account">Balance: </label>
 <br>
 <input type="input" name="balance" />
<br>
 <br>

 <label>&nbsp;</label>
 <input type="submit" value="Add Employee" />


 </form>
 </section>
 
 <br>
 <br>
 
 <div id= "deposit">
  <h1>Deposit</h1>

 <form action="index.php" method="post" id="add_balance">

 <input type="hidden" name="action" value="add_balance">

 
 <label>Select Account:</label>
  <select name="accountSelect">
                <?php foreach( $userInfo as $user ) : ?>
                    <option value="<?php echo $user['AccountID']; ?>">
                        <?php echo $user['AccountID']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
			<br>
			<br>
 
 <label>Deposit: </label>
 <br>
 <input type="input" name="balance" />
 <br />
			
 <label>&nbsp;</label>
 <br>
 <input type="submit" value="Deposit" />
 <br />
 
 </form>
 <br> 
 <a href="../veiw/logout.php"><button>Log Out</button></a>
 </div>

     <a href="?action=show_add_form">Add User Account </a>   
    </main>
</body>
</html>