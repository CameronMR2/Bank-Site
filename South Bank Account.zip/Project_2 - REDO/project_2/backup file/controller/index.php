<?php
	//Start session management with a persistent cookie
	$lifetime = 60 * 60 * 24 * 14;    // 2 weeks in seconds
	session_set_cookie_params($lifetime, '/');
	session_start();

	//Create a cart array if needed
	if (empty($_SESSION['cart12'])) { 
		$_SESSION['cart12'] = array(); 
	}
	
	
	//I attempted to do the MVC way, but met a wall when my require wouldn't work. 
	//Below are the queries to call the data
	$bank = array();
	 //Connect to DB.
	require '../model/database.php';
	
	//write query to display products
	$query = 'SELECT * FROM account';
	// prepare the SQL statement for execute, return PDO statement object
	$statement = $db ->prepare($query);
	//Execute SQL query.
	$statement->execute();	
	// retrieve the data with fetch all
	$bank = $statement->fetchAll();	
	//Close
	$statement->closeCursor();
	
	


	
	 foreach ($bank as $banks) {
		$products[$banks[0]] = array('TypeID' => $banks[1], 'Type' => $banks[1], 'Interest' => $banks[2]);
	 }
	 
	 
	 
	$action = filter_input(INPUT_POST, 'action');
	if ($action==NULL) {
	 $action = filter_input(INPUT_GET, 'action');
	 if ($action ==NULL) {
	 $action = 'list_employees';
	 }// end nested if
	 }//end if
	
	
	if ($action == 'list_employees') {
	 //get the employees by calling function
	//Get user account information
	$userInfo = array();
	 //Connect to DB.
	require '../model/database.php';
	
	//write query to display products
	$query = 'SELECT * FROM bank_account';
	// prepare the SQL statement for execute, return PDO statement object
	$statement = $db ->prepare($query);
	//Execute SQL query.
	$statement->execute();	
	// retrieve the data with fetch all
	$userInfo = $statement->fetchAll();	
	//Close
	$statement->closeCursor();
	 // display the employees
	 
	  foreach ($userInfo as $user) {
		$products[$user[0]] = array('AccountID' => $user[1], 'TypeID' => $user[1], 'FirstName' => $user[2], 'LastName' => $user[3], 'Balance' => $user[4]);
	 }
	 include('../veiw/add_item_view.php');
}else if ($action == 'delete_employee') {
 //get the employee id from post array
 $employee_num = filter_input(INPUT_POST, 'employee_number',
FILTER_VALIDATE_INT);

require 'model/database.php';
 //Create query
 $query = "DELETE FROM bank_account WHERE AccountID = :user_num";
 // prepare the SQL statement for execution, returns a PDO statement
//object
 $statement = $db -> prepare($query);
 // add parameters to statement object
 $statement-> bindValue (':user_num', $employee_num);
 //execute query
 $statement->execute();
 // close cursor and free database connetion
 $statement->closeCursor();
 
 header("Location:.");
 } else if ($action == 'add_employee'){
 $employee_num = filter_input(INPUT_POST, 'accountID');
 $lastName = filter_input(INPUT_POST, 'typeID');
 $firstName = filter_input(INPUT_POST, 'lastName');
 $extension = filter_input(INPUT_POST, 'firstName');
 $balance = filter_input(INPUT_POST, 'balance');
 
 
 //create query
 $addQuery = 'INSERT INTO bank_account
 (AccountID, TypeID, FirstName, LastName, Balance)
 VALUES
 (:accountNumber, :typeID, :firstName, :lastName,
:balance)';
 //try catch
 try {
 // create statement object
 $addStatement = $db-> prepare($addQuery);
 // bind paramenters
 $addStatement->bindValue(':accountNumber', $employeeNumber);
 $addStatement->bindValue(':typeID', $lastName);
 $addStatement->bindValue(':firstName', $firstName);
 $addStatement->bindValue(':lastName', $extension);
 $addStatement->bindValue(':balance', $balance);
 // execute query
 $addStatement->execute();
 // close connection
 $addStatement->closeCursor();
 
 header("Location:.");
 
 }catch (Exception $e){
 $error_message = $e->getMessage();
 echo "Error message " . $error_message;


 }}

	
	

?>