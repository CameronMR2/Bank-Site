<!DOCTYPE HTML>

<?php 
	session_start();
	
	$username = "user"; 
	$password = "password"; 
	
	if (isset($_SESSION['Logged_in']) && $_SESSION['Logged_in'] == true) { 
		header("Location: controller/index.php"); 
	}
	
	if (isset($_POST['username']) && isset($_POST['password'])) {
			if ($_POST['username'] == $username && $_POST['password'] == $password)
				{
					$_SESSION['Logged_in'] = true; 
					header("Location: controller/index.php");
				}
		}
		
?>
<html> 
	<body> 
		<form method="post" action="index.php"> 
			username:</br> 
			<input type="text" name="username"></br> 
			Password:</br> 
			<input type="password" name="password"></br> 
			<input type="submit" value="Login">
			
		</form> 
	</body> 
</html> 