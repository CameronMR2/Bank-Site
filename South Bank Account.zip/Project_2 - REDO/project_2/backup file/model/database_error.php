<! DOCTYPE html>

<html>
	<head>
		<title> Classic Model DB </title>
		<link rel="stylesheet" type="text/css" href:"main.css" />
	</head>
	
	<body>
		<main>
			<h1>DB Error</h1>
			<p>There was an error connecting to the Database.</p>
			<p>Error: <?php echo $error_message; ?> </p>
		</main>
	</body>

</html>