<?
$products = array();
	 //Connect to DB.
	require 'database.php';
	
	//write query to display products
	$query = 'SELECT * FROM account';
	// prepare the SQL statement for execute, return PDO statement object
	$statement = $db ->prepare($query);
	//Execute SQL query.
	$statement->execute();	
	// retrieve the data with fetch all
	$products = $statement->fetchAll();	
	//Close
	$statement->closeCursor();
	
	
	//Get user account information
	$userInfo = array();
	 //Connect to DB.
	require 'database.php';
	
	//write query to display products
	$query = 'SELECT * FROM bank_account';
	// prepare the SQL statement for execute, return PDO statement object
	$statement = $db ->prepare($query);
	//Execute SQL query.
	$statement->execute();	
	// retrieve the data with fetch all
	$userInfo = $statement->fetchAll();	
	//Close
	$statement->closeCursor();
	
	 foreach ($products as $product) {
		$products[$product[0]] = array('TypeID' => $product[1], 'Type' => $product[1], 'Interest' => $products[2]);
	 }
	 
	 foreach ($userInfo as $user) {
		$products[$user[0]] = array('AccountID' => $user[1], 'TypeID' => $user[1], 'FirstName' => $user[2], 'LastName' => $user[3], 'Balance' => $user[4]);
	 }
?>	 