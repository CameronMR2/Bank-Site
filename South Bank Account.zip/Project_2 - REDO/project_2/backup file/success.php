<?php
session_start(); 

	if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] == false) { 
			header("Location: index.php"); 
	}
?> 
<html> 
<header> 
Hey
</header> 
</html> 